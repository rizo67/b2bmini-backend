const path = require('path');


module.exports = path.dirname(process.require.main.filename);